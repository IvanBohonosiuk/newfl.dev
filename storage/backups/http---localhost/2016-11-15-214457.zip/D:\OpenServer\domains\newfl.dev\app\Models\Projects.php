<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Backpack\CRUD\CrudTrait;

class Projects extends Model
{
	use CrudTrait;

     /*
	|--------------------------------------------------------------------------
	| GLOBAL VARIABLES
	|--------------------------------------------------------------------------
	*/

	protected $table = 'projects';
	protected $primaryKey = 'id';
    public $timestamps = true;
	// protected $guarded = ['id'];
	protected $fillable = [
	     'title',
         'description',
         'active',
         'end_date',
         'price',
         'image',
         'files',
         'remote'
    ];
	// protected $hidden = [];
     protected $dates = [
         'created_at',
         'updated_at',
         'deleted_at'
     ];
    protected $casts = [
        'image' => 'array',
        'files' => 'array'
    ];

	/*
	|--------------------------------------------------------------------------
	| FUNCTIONS
	|--------------------------------------------------------------------------
	*/

    public function getActive()
    {
        return $this->published()
            ->order()
            ->get();
	}

    public function getById($id)
    {
        return $this->id($id)
            ->firstOrFail();
    }

	/*
	|--------------------------------------------------------------------------
	| RELATIONS
	|--------------------------------------------------------------------------
	*/

    public function categories()
    {
        return $this->belongsToMany('App\Models\ProjectCats');
    }

    public function user()
    {
        return $this->belongsTo('App\User');
    }

    public function bids()
    {
        return $this->hasMany('App\Models\Bids');
    }

	/*
	|--------------------------------------------------------------------------
	| SCOPES
	|--------------------------------------------------------------------------
	*/

    public function scopePublished($query)
    {
        $query->where(['active'=>1]);
    }
    public function scopeId($query, $id)
    {
        $query->where(['id'=>$id]);
    }

    public function scopeOrder($query)
    {
        $query->orderBy('created_at', 'desc');
    }

	/*
	|--------------------------------------------------------------------------
	| ACCESORS
	|--------------------------------------------------------------------------
	*/

	/*
	|--------------------------------------------------------------------------
	| MUTATORS
	|--------------------------------------------------------------------------
	*/

    public function setImagesAttribute($value)
    {
        $attribute_name = "image";
        $disk = "public";
        $destination_path = "uploads/projects/images/" . date('FY') . "/";

        $this->uploadMultipleFilesToDisk($value, $attribute_name, $disk, $destination_path);
    }

    public function setFilesAttribute($value)
    {
        $attribute_name = "files";
        $disk = "public";
        $destination_path = "uploads/projects/files/" . date('FY') . "/";

        $this->uploadMultipleFilesToDisk($value, $attribute_name, $disk, $destination_path);
    }
}
