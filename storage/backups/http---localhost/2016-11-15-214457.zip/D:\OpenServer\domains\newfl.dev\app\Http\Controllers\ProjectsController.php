<?php

namespace App\Http\Controllers;

use App\Models\Projects;
use Illuminate\Http\Request;

class ProjectsController extends Controller
{
    public function index(Projects $projects)
    {
        $this->data['projects'] = $projects->getActive();

        return view('projects.index', $this->data);
    }
}
